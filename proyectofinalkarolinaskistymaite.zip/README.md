# Proyecto Final

Dicho trabajo trata de crear una página web desde cero, siendo el tema principal una Tienda online de bisuteria.

La elección de este tema fue entre ellos personal, siendo una inspiración pasada de crear una marca propia en relación a la joyería, aprovechando este proyecto para llevarlo a cabo con mayor creatividad y reto. Por otro lado, aún que ya se disponen de muchas tiendas online de bisutería, es una buena herramienta para poder elaborar a cuenta propia un trabajo en relación y por ende, con oportunidad de sacarlo a la luz.

En el que contendra:
1. Inicio (index.html)
2. Catálogo de productos
3. Carrito de compras
4. Página de pago 

Efectos o módulos como el añadir productos a un carrito de compras, sliders de productos destacados, carrouseles, efectos de scroll, menú, etc...

Palabras clave en descripción a la página web:

Elegancia, sutileza y un toque de exclusividad